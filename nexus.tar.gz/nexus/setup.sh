ln -s /opt/snb-tech/Logdetector/nexus /opt/nexus
ln -s /opt/snb-tech/Logdetector/logstash-8.9.0 /opt/collector

